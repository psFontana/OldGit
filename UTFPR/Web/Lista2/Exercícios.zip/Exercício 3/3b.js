elementos = document.getElementsByName("nomePessoa") 

for (let i = 0; i < elementos.length; i++) {
    elementos[i].style.backgroundColor = "yellow"
}