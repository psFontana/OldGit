elementos = document.getElementsByClassName("btnPar") 

for (let i = 0; i < elementos.length; i++) {
    elementos[i].style.color = "red"
}